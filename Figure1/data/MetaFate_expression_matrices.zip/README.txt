Supplementary Data 5 - MetaFate expression matrices

MetaFate single-cell RNA-seq of 4,485 LSK cells from 5 DRAG-barcoded mice (10x Genomics 3').

MetaFate_RNA_counts.csv
  UMI counts after QC: 11,502 genes (rows) x 4,485 cells (columns). Gm, Rik and Rp genes were removed (Methods).
  Normalised expression used in the paper (Seurat LogNormalize, scale factor 10,000):
    normalised[g, c] = ln(1 + 10000 * counts[g, c] / sum over all genes in this file of counts[, c])
  Note: the per-cell total is the column sum of this file, not nCount_RNA (computed before gene filtering).
  Gene names such as Sept1 or March1 are converted to dates if the file is opened directly in Excel; import the
  gene column as text.

MetaFate_cell_metadata.csv
  One row per cell, same cells and order as the columns of MetaFate_RNA_counts.csv.
  orig.ident = mouse; nCount_RNA, nFeature_RNA, percent.mt = QC metrics; Con.seq = DRAG barcode sequence
  (nb = no barcode); Myeloid, Erythroid = abundance of the cell's barcode in mature myeloid / erythroid cells,
  *_cellnorm = the same scaled to sorted cell numbers (clone size); Con.seq_perexpt = barcode + experiment;
  pgen = generation probability of the barcode; barcoded = RNA barcode recovered; phases, G1_score, S_score,
  G2M_score = cell-cycle assignment (cyclone); bias.score = lineage-bias score (Methods).
